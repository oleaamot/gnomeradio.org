require "pgf"
require "pgf.gd"

pgf.gd.planar = {}

return pgf.gd.planar
