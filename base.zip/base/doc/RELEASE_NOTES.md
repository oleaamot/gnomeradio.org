Emergency release to fix pgfplots which depends on unreleased parts of PGF.
